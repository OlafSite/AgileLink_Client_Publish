const r=""+new URL("111-1cc4a614.jpg",import.meta.url).href;export{r as _};
